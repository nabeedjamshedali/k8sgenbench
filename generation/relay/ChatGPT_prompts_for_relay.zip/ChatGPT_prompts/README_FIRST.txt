HOW TO RUN THESE PROMPTS (please read once before starting)
=============================================================

There are 38 prompt files in the "prompts" folder, numbered 01 to 38.
Each one is a separate run. Please do them in number order.

SETUP (once)
- Use ChatGPT on the web with the default model (do not switch models).
- Use a Temporary Chat (the "Temporary" toggle at the top) for EVERY prompt,
  so memory and custom instructions cannot affect the answers.
  If Temporary Chat is not available, turn off Memory and Custom
  Instructions in Settings > Personalization before you start.
- Do not turn on web search, deep research, canvas or any other tool.

FOR EACH PROMPT FILE (01, 02, 03 ...)
1. Start a NEW temporary chat. Never reuse a chat, even for the same project.
2. Open the prompt file, select ALL its text (Ctrl+A), copy, paste it into
   ChatGPT and send. Do not add, remove or change anything.
3. Wait for the full answer. Do NOT send any follow-up message
   (no "continue", no corrections, no "thanks").
4. Click the copy button under ChatGPT's answer.
5. In the "replies" folder, create a text file with EXACTLY the same name
   as the prompt file (e.g. 01__P02_n8n__neutral__s1.txt), paste the answer, save.
6. Tick it in the checklist below (optional) and go to the next file.

Some prompts appear 3 times (s1, s2, s3). That is on purpose: the same
prompt is run in 3 separate new chats. Each reply file must come from its
own new chat; please never copy one answer into several files.

SPECIAL CASES
- If an answer is cut off or stops early, save it exactly as it is.
  Do not ask it to continue.
- Prompts 07-12 (P03_grafana) are very long (~143,000 characters).
  If ChatGPT turns the paste into an attached file, that is fine, just send it.
  If it refuses because the message is too long, write that in NOTES.txt
  and move on.
- If ChatGPT shows an error before answering, try again in a new chat and
  add a short note in NOTES.txt.

WHEN DONE
Zip the "replies" folder (it includes NOTES.txt) and send it back.

CHECKLIST
[ ] 01__P02_n8n__neutral__s1.txt
[ ] 02__P02_n8n__neutral__s2.txt
[ ] 03__P02_n8n__neutral__s3.txt
[ ] 04__P02_n8n__production__s1.txt
[ ] 05__P02_n8n__production__s2.txt
[ ] 06__P02_n8n__production__s3.txt
[ ] 07__P03_grafana__neutral__s1.txt
[ ] 08__P03_grafana__neutral__s2.txt
[ ] 09__P03_grafana__neutral__s3.txt
[ ] 10__P03_grafana__production__s1.txt
[ ] 11__P03_grafana__production__s2.txt
[ ] 12__P03_grafana__production__s3.txt
[ ] 13__P04_voting-app__neutral__s1.txt
[ ] 14__P04_voting-app__neutral__s2.txt
[ ] 15__P04_voting-app__neutral__s3.txt
[ ] 16__P04_voting-app__production__s1.txt
[ ] 17__P04_voting-app__production__s2.txt
[ ] 18__P04_voting-app__production__s3.txt
[ ] 19__P05_emojivoto__neutral__s2.txt
[ ] 20__P05_emojivoto__neutral__s3.txt
[ ] 21__P05_emojivoto__production__s2.txt
[ ] 22__P05_emojivoto__production__s3.txt
[ ] 23__P07_online-boutique__neutral__s2.txt
[ ] 24__P07_online-boutique__neutral__s3.txt
[ ] 25__P07_online-boutique__production__s2.txt
[ ] 26__P07_online-boutique__production__s3.txt
[ ] 27__P08_sock-shop__neutral__s1.txt
[ ] 28__P08_sock-shop__neutral__s2.txt
[ ] 29__P08_sock-shop__neutral__s3.txt
[ ] 30__P08_sock-shop__production__s1.txt
[ ] 31__P08_sock-shop__production__s2.txt
[ ] 32__P08_sock-shop__production__s3.txt
[ ] 33__P10_k8s-dashboard__neutral__s1.txt
[ ] 34__P10_k8s-dashboard__neutral__s2.txt
[ ] 35__P10_k8s-dashboard__neutral__s3.txt
[ ] 36__P10_k8s-dashboard__production__s1.txt
[ ] 37__P10_k8s-dashboard__production__s2.txt
[ ] 38__P10_k8s-dashboard__production__s3.txt
